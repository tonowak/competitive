int = 32 bity = 32b = 4B (bo 1B = 8b)
1KB = 1024B = 2^10 B ~= 1000B
1MB = 1024KB
long long = 64 bity
